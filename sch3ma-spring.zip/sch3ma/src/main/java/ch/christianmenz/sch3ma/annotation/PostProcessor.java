package ch.christianmenz.sch3ma.annotation;

/**
 * @author Christian Menz
 */
public @interface PostProcessor {
}
